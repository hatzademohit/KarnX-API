<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\xampp_8.2\htdocs\KarnX-API\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>