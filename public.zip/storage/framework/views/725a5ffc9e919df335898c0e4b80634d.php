<?php echo e($slot); ?>

<?php /**PATH E:\xampp_8.2\htdocs\KarnX-API\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>